from flask import Flask, render_template, request, session, redirect, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)


app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = ""
app.config["MYSQL_DB"] = "pw_responsi" 


mysql = MySQL(app)

app.secret_key = "Ini-sangat-rahasia"


portfolio = [
    {
        'title': 'Project 1',
        'image_url': 'path/to/image1.jpg',
        'description': 'Description of Project 1.',
        'technologies': 'Tech 1, Tech 2',
        'link': 'https://example.com/project1'
    },
    {
        'title': 'Project 2',
        'image_url': 'path/to/image2.jpg',
        'description': 'Description of Project 2.',
        'technologies': 'Tech 3, Tech 4',
        'link': 'https://example.com/project2'
    },
   
]


@app.route('/portfolio')
def portfolio_page():
    return render_template('portfolio.html', portfolio=portfolio)

if __name__ == '__main__':
    app.run(debug=True)


@app.route("/") 
def index():
    if 'is_logged_in' in session:
        cur = mysql.connect.cursor()

        cur.execute("SELECT * FROM users")

        users = cur.fetchall()

        cur.close()

        return render_template("index.html", data=users)
    else:
        return redirect(url_for('login'))



@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        nama = request.form['inpNama']
        email = request.form['inpEmail']
        password = request.form['inpPass']

        cur = mysql.connect.cursor()
        cur.execute('INSERT INTO users (username, email, password) VALUES (%s, %s, %s)', (nama, email, password))
        mysql.connect.commit()
        cur.close()
        return redirect(url_for('login'))
    else:
        return render_template('register.html')



@app.route("/login",methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['inpEmail']
        password = request.form['inpPass']

        cur = mysql.connect.cursor()

        cur.execute("SELECT * FROM users WHERE email=%s AND password=%s",(email,password))

        users = cur.fetchone()

        if users:
            session['is_logged_in'] = True
            session['username'] = users[1]
            return redirect(url_for('index'))
        else:
            pesanError = "Cek email dan password anda"
            return render_template("login.html", msg=pesanError)
    else:
        return render_template("login.html")



@app.route("/logout")
def logout():
    session.pop("is_logged_in", None)
    session.pop("username", None)

    return redirect(url_for("login"))



if __name__ == "__main__":
    app.run(debug=True)